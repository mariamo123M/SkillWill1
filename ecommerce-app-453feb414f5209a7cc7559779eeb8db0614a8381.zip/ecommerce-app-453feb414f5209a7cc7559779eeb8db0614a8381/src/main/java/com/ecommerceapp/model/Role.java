package com.ecommerceapp.model;

public enum Role {
    ADMIN,
    USER
}
